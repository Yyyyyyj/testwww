在jar包所在路径打开终端
执行java -jar todoList-0.0.1-SNAPSHOT.jar
即可启动终端